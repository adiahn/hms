<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - Al-Qalam University Hostel Management System - Developed by Musa Ahmed Musa <a href="https://codeastro.com"></a>
</footer>