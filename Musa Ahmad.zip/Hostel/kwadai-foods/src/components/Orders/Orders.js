import React from 'react'
import './Orders.css'


const Orders = () => {
  return (
    <div className='orders'>
      
    </div>
  )
}

export default Orders
